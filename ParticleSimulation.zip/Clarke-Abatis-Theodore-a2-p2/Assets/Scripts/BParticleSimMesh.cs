using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Check this out we can require components be on a game object!
[RequireComponent(typeof(MeshFilter))]

public class BParticleSimMesh : MonoBehaviour
{
    public struct BSpring
    {
        public float kd;                        // damping coefficient
        public float ks;                        // spring coefficient
        public float restLength;                // rest length of this spring
        public int attachedParticle;            // index of the attached other particle (use me wisely to avoid doubling springs and sprign calculations)
    }

    public struct BContactSpring
    {
        public float kd;                        // damping coefficient
        public float ks;                        // spring coefficient
        public float restLength;                // rest length of this spring (think about this ... may not even be needed o_0
        public Vector3 attachPoint;             // the attached point on the contact surface
    }

    public struct BParticle
    {
        public Vector3 position;                // position information
        public Vector3 velocity;                // velocity information
        public float mass;                      // mass information
        public BContactSpring contactSpring;    // Special spring for contact forces
        public bool attachedToContact;          // is thi sparticle currently attached to a contact (ground plane contact)
        public List<BSpring> attachedSprings;   // all attached springs, as a list in case we want to modify later fast
        public Vector3 currentForces;           // accumulate forces here on each step        
    }

    public struct BPlane
    {
        public Vector3 position;                // plane position
        public Vector3 normal;                  // plane normal
    }

    public float contactSpringKS = 1000.0f;     // contact spring coefficient with default 1000
    public float contactSpringKD = 20.0f;       // contact spring daming coefficient with default 20

    public float defaultSpringKS = 100.0f;      // default spring coefficient with default 100
    public float defaultSpringKD = 1.0f;        // default spring daming coefficient with default 1

    public bool debugRender = false;            // To render or not to render


    /*** 
     * I've given you all of the above to get you started
     * Here you need to publicly provide the:
     * - the ground plane transform (Transform)
     * - handlePlaneCollisions flag (bool)
     * - particle mass (float)
     * - useGravity flag (bool)
     * - gravity value (Vector3)
     * Here you need to privately provide the:
     * - Mesh (Mesh)
     * - array of particles (BParticle[])
     * - the plane (BPlane)
     ***/

     public Transform groundPlaneTransform;
     public bool handlePlaneCollisions = true;
     public float particleMass = 1.0f;
     public bool useGravity = true;
     public Vector3 gravity = new Vector3(0, -9.8f, 0);

     private Mesh mesh;
     private BParticle[] particles;
     private BPlane groundPlane;

    /// <summary>
    /// Init everything
    /// HINT: in particular you should probbaly handle the mesh, init all the particles, and the ground plane
    /// HINT 2: I'd for organization sake put the init particles and plane stuff in respective functions
    /// HINT 3: Note that mesh vertices when accessed from the mesh filter are in local coordinates.
    ///         This script will be on the object with the mesh filter, so you can use the functions
    ///         transform.TransformPoint and transform.InverseTransformPoint accordingly 
    ///         (you need to operate on world coordinates, and render in local)
    /// HINT 4: the idea here is to make a mathematical particle object for each vertex in the mesh, then connect
    ///         each particle to every other particle. Be careful not to double your springs! There is a simple
    ///         inner loop approach you can do such that you attached exactly one spring to each particle pair
    ///         on initialization. Then when updating you need to remember a particular trick about the spring forces
    ///         generated between particles. 
    /// </summary>
    void Start()
    {
        InitParticles();
        InitPlane();
    }

    private void InitParticles()
{
    Mesh originalMesh = GetComponent<MeshFilter>().sharedMesh;
    mesh = Instantiate(originalMesh);
    GetComponent<MeshFilter>().mesh = mesh; // Use a copy of the original mesh to avoid modifying it directly

    Vector3[] vertices = mesh.vertices;
    particles = new BParticle[vertices.Length];
    
    // Initialize all particle positions
    for(int i = 0; i < particles.Length; i++)
    {
        particles[i].position = transform.TransformPoint(vertices[i]);
        particles[i].velocity = Vector3.zero;
        particles[i].mass = particleMass;
        particles[i].attachedSprings = new List<BSpring>();
        particles[i].currentForces = Vector3.zero;
        particles[i].attachedToContact = false;
    }

    // Create springs with correct rest lengths
    for(int i = 0; i < particles.Length; i++)
    {
        for(int j = i + 1; j < particles.Length; j++)
        {
            BSpring spring = new BSpring();
            spring.ks = defaultSpringKS;
            spring.kd = defaultSpringKD;
            spring.restLength = Vector3.Distance(particles[i].position, particles[j].position);
            spring.attachedParticle = j;
            particles[i].attachedSprings.Add(spring);
        }
    }
}

    private void InitPlane()
    {
        groundPlane.position = groundPlaneTransform.position;
        groundPlane.normal = groundPlaneTransform.up; 
    }


    private void UpdateMesh()
    {
        Vector3[] vertices = mesh.vertices;
        for(int i = 0; i<particles.Length; i++)
        {
            vertices[i] = transform.InverseTransformPoint(particles[i].position);
        }
        mesh.vertices = vertices;
        mesh.RecalculateNormals();
        mesh.RecalculateBounds();
    }

    private void ResetParticleForces()
    {
        for (int i = 0; i < particles.Length; i++)
        {
            particles[i].currentForces = Vector3.zero;
        }
    }

    private void CalculateSpringForces()
    {
        for (int i = 0; i < particles.Length; i++)
        {
            for (int j = 0; j < particles[i].attachedSprings.Count; j++)
            {
                BSpring spring = particles[i].attachedSprings[j];
                int otherParticleIndex = spring.attachedParticle;
                
                // Get positions and velocities
                Vector3 xi = particles[i].position;
                Vector3 xj = particles[otherParticleIndex].position;
                Vector3 vi = particles[i].velocity;
                Vector3 vj = particles[otherParticleIndex].velocity;
                
                // Calculate spring force using the formula
                Vector3 deltaX = xi - xj;
                Vector3 deltaV = vi - vj;
                float distance = deltaX.magnitude; // |xi - xj|
                
                if (distance > 0.0001f) // Avoid division by zero
                {
                    Vector3 direction = deltaX / distance;
                    
                    // Spring force: ks * (l - |xi - xj|) * direction - kd * ((vi - vj) dot direction) * direction
                    float springMagnitude = spring.ks * (spring.restLength - distance);
                    float dampingMagnitude = spring.kd * Vector3.Dot(deltaV, direction);
                    
                    Vector3 springForce = springMagnitude * direction - dampingMagnitude * direction;
                    
                    // Apply force to particle i
                    particles[i].currentForces += springForce;
                    
                    // Apply equal and opposite force to particle j using negative trick
                    particles[otherParticleIndex].currentForces += -springForce;
                }
            }
        }
    }


    private void HandlePlaneCollisions()
    {
        if (!handlePlaneCollisions) return;
        
        for (int i = 0; i < particles.Length; i++)
        {
            Vector3 xp = particles[i].position;
            Vector3 vp = particles[i].velocity;
            
            // Calculate distance from plane: (xp - xg) dot n
            float distance = Vector3.Dot(xp - groundPlane.position, groundPlane.normal);
            
            // If particle is below/penetrating the plane
            if (distance < Mathf.Epsilon)
            {
                if (!particles[i].attachedToContact)
                {
                    // First time penetrating - create contact spring
                    particles[i].attachedToContact = true;
                    particles[i].contactSpring.ks = contactSpringKS;
                    particles[i].contactSpring.kd = contactSpringKD;
                    // Attach point is closest point on plane
                    particles[i].contactSpring.attachPoint = xp - distance * groundPlane.normal;
                }

                // Apply contact force: -ks * ((xp - xg) dot n) * n - kd * vp
                Vector3 contactForce = -contactSpringKS * distance * groundPlane.normal - contactSpringKD * vp;

                // Only apply force if it's pushing the particle away from the plane
                if(Vector3.Dot(contactForce, groundPlane.normal) > 0) particles[i].currentForces += contactForce; 
            }
            else
            {
                // Not penetrating anymore
                particles[i].attachedToContact = false;
            }
        }
    }

    private void ApplyGravity()
    {
        if (!useGravity) return;
        
        for (int i = 0; i < particles.Length; i++)
        {
            particles[i].currentForces += gravity * particles[i].mass;
        }
    }

    private void Integrate()
    {
        float dt = Time.fixedDeltaTime;
        
        // Sympletic Euler Integration for each particle
        for (int i = 0; i < particles.Length; i++)
        {
            Vector3 acceleration = particles[i].currentForces / particles[i].mass;
            
            particles[i].velocity += acceleration * dt;
            
            particles[i].position += particles[i].velocity * dt;
        }
    }

    private void FixedUpdate()
    {
        ResetParticleForces();
        CalculateSpringForces();
        ApplyGravity();
        HandlePlaneCollisions();
        Integrate();
        UpdateMesh();
    }

    /*** BIG HINT: My solution code has as least the following functions
     * InitParticles() X
     * InitPlane() X
     * UpdateMesh() (remember the hint above regarding global and local coords)
     * ResetParticleForces()
     * ...
     ***/



    /// <summary>
    /// Draw a frame with some helper debug render code
    /// </summary>
    public void Update()
    {
        // This will work if you have a correctly made particles array
        if (debugRender)
        {
            int particleCount = particles.Length;
            for (int i = 0; i < particleCount; i++)
            {
                Debug.DrawLine(particles[i].position, particles[i].position + particles[i].currentForces, Color.blue);

                int springCount = particles[i].attachedSprings.Count;
                for (int j = 0; j < springCount; j++)
                {
                    Debug.DrawLine(particles[i].position, particles[particles[i].attachedSprings[j].attachedParticle].position, Color.red);
                }
            }
            
        }
        
    }
}
