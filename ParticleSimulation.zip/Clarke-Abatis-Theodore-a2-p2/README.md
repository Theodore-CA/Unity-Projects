# Soft Body Simulation Implementation

1. The particles are generated from the mesh filter by using an array of Vector3's holding all the mesh.vertices. Then, a BParticle array vertices.Length in size is used to initialize every particle. It loops over every particle setting the position in world coordinates (particles[i].position = transform.TransformPoint(vertices[i]);), the velocity to zero, the particle mass to the default, the attached springs list to an empty list of Bsprings, the current forces to zero, and the contact springs to false.

2. The springs are initialized after the particles. This is done by using a nested loop scheme to ensure no doubling on springs. It loops over every particle, and only particles after the current. 
    for(int i = 0; i < particles.Length; i++) <-- Every particle
    for(int j = i + 1; j < particles.Length; j++) <-- Every particle after the current
This ensures that particle 0 has 23 connections, particle 1 has 22, and so on. Each spring initalized this way get its defaults set, rest length calculated (Vector3.Distance(particles[i].position, particles[j].position);) in world coordinates, and added to arrached springs.

3. The plane is initialized using the BPlane object.

4. The gound contact pentaly springs are created in the HandlePlaneCollisions() function when the particle's distiance to the ground is less than epsilion, and there is no current attached spring. The attach point is calculated at the moment of penetration using the formula given in class (xp - distance * groundPlane.normal;). Finally, they are initialized with the default ks and kd provided in the file.

5. The ground contact penalty is calculated using the formula provided in the assignment description. An important note here, this simulation is not 1:1 with the example video in the assignment description. The key difference is that the green cube doesn't flip over. I was having issues where the contact springs were "pulling" towards the plane. This was due to the particle being read as less than epslion even though it had left the ground only for 1 frame, causing the particles being "pulled" towards the plane with a negative y value for a short time. This reduced more energy than intended causing the cubes to behave differently. My solution was to only add the penalty when the dot product between the contact force and the ground normal was positive (Vector3.Dot(contactForce, groundPlane.normal) > 0). This means that when the force is pushing the cube away from the plane it gets added, eliminating the 1 frame of "pull". Lastly, the contact springs are detached when distance is greater than epsilon.

6. At the end of each simulation loop, UpdateMesh() is called. After all the calculations are done in world coordinates, this function puts them back into local and updates the mesh properties:
    mesh.vertices = vertices;
    mesh.RecalculateNormals();
    mesh.RecalculateBounds();

7. The particle-particle spring forces are calculated usign the formula provided in the assignment description for every attached spring, and the opposite force is added as a negative to avoid pointless calculations. This is the trick shown on the course slides.
    particles[i].currentForces += springForce;
    particles[otherParticleIndex].currentForces += -springForce;

8. As mentioned before, UpdateMesh() calls RecalculateNormals() and RecalculateBounds() to update the mesh appropriately.

9. The function Integrate() uses the Sympletic Euler integration scheme to update each particle correctly.

10. The simulatior is in a 0.02 second time step, where every calculation and update function is called from FixedUpdate() to ensure more deterministic behaviour that doesnt rely on framerate.

11. All cubes used use their appropriate kd's and ks's. Blue: ks = 200 kd = 0, Red: ks = 80 kd = 0.8, Green: ks = 45 kd = 0.2.