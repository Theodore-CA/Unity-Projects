# AISystems

1. All boids are correctly initialized with `initializationRadius` and `initializationForwardRandomRange`, as well as the prefab being laded onto each boid correctly.

2. At the start of fixed update `ResetBoidForces()` is called, which resets all boids `currentForces` to 0.

3. Vision for each boid is handled correctly using `Vector3.Dot(boids[i].forward, toNeighbour.normalized) < 0f` to see in the 180 degrees infront of it and `neighbourDistance`
by checking `if (sqrDist < sqrNeighbourDistance)`. However, the marking says building a neighbor list which I don't do. I just check the boids vision and apply the rules
for each boid it can see other than itself.

4. 5. 6. The three rules are applied (probably) correctly in the `ThreeRules()` function. I do the vision check for each boid other than itself, and if the boid can see
another boid it adds it to the sum. After each boid is summed, I average and normalize them. Finally, I apply the steering force using `(ω_k * ((rule_ki * α) - v_i))` as
recommended in the assignment description.
    NOTE: This is a bit messy as its in just one function (as well as the wander rule), and the boids don't move quite as fast as they do in the example in the assignment
    description. I think this may be because I'm applying some force one to many times, but I have a lot of other projects to do so I don't have time to pin down the error.

7. The wander rule is applied when `neighborCount == 0` and just does the steering force calculation using its velocity.

8. Obsticle avoidance is applied by doing `Physics.OverlapSphere(boids[i].position, obstacleCheckRadius, obstacleLayerMask);` and for each collider it finds it checks the closest
point by using `hitCollider.ClosestPointOnBounds(boids[i].position);`. If there is a point detected it adds the avoidance force.

9. I add the world absticle check using the coordinates listed in the assginemnt `X-axis -8, 8; Z-axis -8, 8; Y-axis 1, 4`. I do 2 simple if checks for each plane and apply the opposite
vector if the boid past the bound: `Vector3(-1f, 0f, 0f);` and so on.
    NOTE: I think there are a few issues with adding my object avoidance force to `currentTotalForces`. This is because my boids dont fly up and down as much as they should compared to 
    the example in the assignment description, and they tend to circulate either counter-clockwise, or clockwise. They do seperate and interact with the pillars in the middle, but they
    will always flow in that pattern (it looks more like a fluid simulation in a toilet lol). This may be due to my not applying the avoidance forces properly, or the three rules are wrong and the
    forces there are too strong causing the boids not to behave properly. Again, I have a bunch of other things to work on right now, so I don't have enough time to find whats causing it.
    It looks believeable enough for a bunch of flies in a box.

10. As mentioned before, I add all those calculations to total forces, and integrate with them. There are some issues that I'm not sure of, but I think its at least paritally correct.

11. Set goal is implemented by finding the NavMesh hit positions for the goal and the boid's current position using `NavMesh.SamplePosition(goal, out goalHit, 5.0f, NavMesh.AllAreas)` and
`NavMesh.SamplePosition(boids[0].position, out boidHit, 5.0f, NavMesh.AllAreas)`. Using those positions I do `NavMesh.CalculatePath(boidHit.position, boidZeroGoal, NavMesh.AllAreas, boidZeroPath);`
to get the list of corners in `boidZeroPath`.

12. boidZero's pathfinding is handled by first checking if its still navagaitng in `setGoal()`, then checking if the corners exist. If there are enough corners, and the boid is not currently
navagating, it begins its navagation. `ApplyBoidZeroPathFollowing()` gets the current position of the boid and the target corner, then steers the boid in the direction of the current corner.
if the boid has reached the target threshold within `1.0f` distance, it finds the next target corner in the corners list. If each corner has been traversed, the boid has reached its destination
and the traversing bool is set to false and the boid becomes ready to pathfind again.
    NOTE: This one actually works properly for the most part. The only issue is minor, in that when it reaches a corner it might hover there for a second still trying to find the corner and
    attempt to move to the next corner. This is due to the `1.0f` distance check, and if this were bigger it would probably fix it. The boid still reaches the end of its path properly, it
    might just get caught on a corner.

13. The symplectic Euler scheme is implemented the same way it was in assignment 2. It has a few tweeks, like updating the boid prefab position, but it's largley the same.

14. The simulator loop calculates the forces and applies them properly within the deltatime of `FixedUpdate()`. The forces are reset at the top, calculated in the middle, and integrated at the end.

15. All the default values in the scene have not been tampered with. However, I did add the `obstacleLayerMask` variable to the `Swarm.cs` script to help with object processing.

Final note: This project isn't quite perfect as I didn't have much time to work on it, but I'm satisfied with the current implementation of boids. They look fine enough for me to believe that they are
flies trapped in a box when I look at it in a passing glance.