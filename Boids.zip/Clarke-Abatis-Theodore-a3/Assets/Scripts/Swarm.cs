using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Swarm : MonoBehaviour
{
    public struct BBoid
    {
        public Vector3 position;
        public Vector3 forward;
        public Vector3 velocity;
        public Vector3 alignment;
        public Vector3 cohesion;
        public Vector3 separation;
        public Vector3 obstacle;
        public Vector3 currentTotalForce;
    }

    public Transform boidPrefab;

    public int numberOfBoids = 200;

    public float boidForceScale = 20f;

    public float maxSpeed = 5.0f;

    public float rotationSpeed = 40.0f;

    public float obstacleCheckRadius = 1.0f;

    public float separationWeight = 1.1f;
    
    public float alignmentWeight = 0.5f;

    public float cohesionWeight = 1f;

    public float goalWeight = 1f;

    public float obstacleWeight = 0.9f;

    public float wanderWeight = 0.3f;

    public float neighbourDistance = 2.0f;

    public float initializationRadius = 1.0f;

    public float initializationForwardRandomRange = 50f;

    private BBoid[] boids;

    private Transform[] boidObjects;

    private float sqrNeighbourDistance;

    private Vector3 boidZeroGoal;
    private NavMeshPath boidZeroPath;
    private int currentCorner;
    private bool boidZeroNavigatingTowardGoal = false;
    public LayerMask obstacleLayerMask;


    /// <summary>
    /// Start, this function is called before the first frame
    /// </summary>
    private void Start()
    {
        boids = new BBoid[numberOfBoids];
        boidObjects = new Transform[numberOfBoids];
        InitBoids();
    }

    /// <summary>
    /// Initialize the array of boids
    /// </summary>
    private void InitBoids()
    {
       for(int i = 0; i < numberOfBoids; i++)
       {
           boids[i] = new BBoid();
           boids[i].position = transform.position + Random.insideUnitSphere * initializationRadius;
           boids[i].forward = Random.insideUnitSphere * initializationForwardRandomRange;
           boidObjects[i] = Instantiate(boidPrefab, boids[i].position, Quaternion.identity);
           boidObjects[i].forward = boids[i].forward.normalized;
       }
       
    }


    /// <summary>
    /// Reset the particle forces
    /// </summary>
    public void ResetBoidForces()
    {
        for(int i = 0; i < boids.Length; i++)
        {
            boids[i].currentTotalForce = Vector3.zero;
        }
    }

    public void ThreeRules()
    {
        int count = boids.Length;
        sqrNeighbourDistance = neighbourDistance * neighbourDistance;

        for (int i = 0; i < count; i++)
        {
            Vector3 alignment = Vector3.zero;
            Vector3 cohesion = Vector3.zero;
            Vector3 separation = Vector3.zero;

            int neighbourCount = 0;

            for (int j = 0; j < count; j++)
            {
                if (i == j) continue;

                Vector3 toNeighbour = boids[j].position - boids[i].position;
                float sqrDist = toNeighbour.sqrMagnitude;

                if (sqrDist < sqrNeighbourDistance)
                {
                    // 180 degree FOV: only in front (dot >= 0)
                    if (Vector3.Dot(boids[i].forward, toNeighbour.normalized) < 0f) continue;

                    neighbourCount++;

                    // Alignment: average neighbour velocity/forward
                    alignment += boids[j].forward;

                    // Cohesion: average neighbour position
                    cohesion += boids[j].position;

                    // Separation: push away
                    separation -= toNeighbour / (sqrDist + 0.0001f);
                }
            }

            if (neighbourCount > 0)
            {
                alignment /= neighbourCount;
                cohesion /= neighbourCount;

                // Turn cohesion into a direction toward the center
                cohesion = (cohesion - boids[i].position).normalized;

                alignment = alignment.normalized;
                separation = separation.normalized;
            }

            boids[i].alignment = alignment;
            boids[i].cohesion = cohesion;
            boids[i].separation = separation;

            // --- Steering forces (ω_k * ((rule_ki * α) - v_i)) ---
            Vector3 v = boids[i].velocity;

            if (neighbourCount > 0)
            {
                // Normal 3 rules
                Vector3 alignDesired      = alignment   * boidForceScale;
                Vector3 cohesionDesired   = cohesion    * boidForceScale;
                Vector3 separationDesired = separation  * boidForceScale;

                Vector3 alignSteer      = (alignDesired    - v) * alignmentWeight;
                Vector3 cohesionSteer   = (cohesionDesired - v) * cohesionWeight;
                Vector3 separationSteer = (separationDesired - v) * separationWeight;

                boids[i].currentTotalForce += alignSteer + cohesionSteer + separationSteer;
            }
            else
            {
                // No neighbours: wander
                if (v.sqrMagnitude > 0.0001f)
                {
                    Vector3 wanderDir     = v.normalized;         
                    Vector3 wanderDesired = wanderDir * boidForceScale;
                    Vector3 wanderSteer   = (wanderDesired - v) * wanderWeight;

                    boids[i].currentTotalForce += wanderSteer;
                }
            }
        }
    }

    public void ObstacleAvoidance()
    {
        int count = boids.Length;
        for (int i = 0; i < count; i++)
        {
            Collider[] hitColliders = Physics.OverlapSphere(boids[i].position, obstacleCheckRadius, obstacleLayerMask);
            Vector3 avoidanceForce = Vector3.zero;
            foreach (var hitCollider in hitColliders)
            {
                Vector3 toObstacle = boids[i].position - hitCollider.ClosestPointOnBounds(boids[i].position);
                float distance = toObstacle.magnitude;
                if (distance > 0f)
                {
                    avoidanceForce += toObstacle.normalized;
                }
            }
            // --- World-bounds "obstacles" ---
            const float minX = -8f, maxX = 8f;
            const float minZ = -8f, maxZ = 8f;
            const float minY =  1f, maxY = 4f;

            Vector3 pos = boids[i].position;

            // X bounds
            if (pos.x > maxX)
            {
                // push back toward -X
                avoidanceForce += new Vector3(-1f, 0f, 0f);
            }
            else if (pos.x < minX)
            {
                // push toward +X
                avoidanceForce += new Vector3(1f, 0f, 0f);
            }

            // Z bounds
            if (pos.z > maxZ)
            {
                avoidanceForce += new Vector3(0f, 0f, -1f);
            }
            else if (pos.z < minZ)
            {
                avoidanceForce += new Vector3(0f, 0f, 1f);
            }

            // Y bounds
            if (pos.y > maxY)
            {
                avoidanceForce += new Vector3(0f, -1f, 0f);
            }
            else if (pos.y < minY)
            {
                avoidanceForce += new Vector3(0f, 1f, 0f);
            }

            boids[i].obstacle = avoidanceForce;
            

            boids[i].currentTotalForce += avoidanceForce * obstacleWeight * boidForceScale;
        }
    }

    /// <summary>
    /// Sim Loop
    /// </summary>
    private void FixedUpdate()
    { 
        ResetBoidForces();
        ThreeRules();
        ObstacleAvoidance();
        ApplyBoidZeroPathFollowing();
        Integrate();
    }


    private void Integrate()
    {
        float dt = Time.fixedDeltaTime;
        int boidCount = boids.Length;

        // Sympletic Euler Integration for each boid
        for (int i = 0; i < boidCount; i++)
        {
            // Update velocity
            boids[i].velocity += boids[i].currentTotalForce * dt;

            // Clamp speed
            if (boids[i].velocity.magnitude > maxSpeed)
            {
                boids[i].velocity = boids[i].velocity.normalized * maxSpeed;
            }

            // Update position
            boids[i].position += boids[i].velocity * dt;

            // Update forward direction
            if (boids[i].velocity.sqrMagnitude > 0.0001f)
            {
                Vector3 newForward = Vector3.Slerp(boids[i].forward, boids[i].velocity.normalized, rotationSpeed * dt);
                boids[i].forward = newForward.normalized;
            }

            // Update the corresponding GameObject's transform
            boidObjects[i].position = boids[i].position;
            boidObjects[i].forward = boids[i].forward;
        }
    }


    private void Update()
    {
        //Render information for boidzero, useful for debugging forces and path planning
        int boidCount = boids.Length;
        for (int i = 1; i < boidCount; i++)
        {
            Vector3 boidNeighbourVec = boids[i].position - boids[0].position;
            if (boidNeighbourVec.sqrMagnitude < sqrNeighbourDistance &&
                    Vector3.Dot(boidNeighbourVec, boids[0].forward) > 0f)
            { 
                Debug.DrawLine(boids[0].position, boids[i].position, Color.blue);
            }
        }
        
        Debug.DrawLine(boids[0].position, boids[0].position + boids[0].alignment, Color.green);
        Debug.DrawLine(boids[0].position, boids[0].position + boids[0].separation, Color.magenta);
        Debug.DrawLine(boids[0].position, boids[0].position + boids[0].cohesion, Color.yellow);
        Debug.DrawLine(boids[0].position, boids[0].position + boids[0].obstacle, Color.red);

        if (boidZeroPath != null)
        {
            int cornersLength = boidZeroPath.corners.Length;
            for (int i = 0; i < cornersLength - 1; i++)
                Debug.DrawLine(boidZeroPath.corners[i], boidZeroPath.corners[i + 1], Color.black);
        }
    }


    public void SetGoal(Vector3 goal)
    {
        NavMeshHit goalHit;
        NavMeshHit boidHit;
        if(boidZeroNavigatingTowardGoal)
        {
            // Already navigating toward a goal
            return;
        }
        if (NavMesh.SamplePosition(goal, out goalHit, 5.0f, NavMesh.AllAreas) && NavMesh.SamplePosition(boids[0].position, out boidHit, 5.0f, NavMesh.AllAreas))
        {
            boidZeroGoal = goalHit.position;

            boidZeroPath = new NavMeshPath();
            NavMesh.CalculatePath(boidHit.position, boidZeroGoal, NavMesh.AllAreas, boidZeroPath);

            currentCorner = 0;
            boidZeroNavigatingTowardGoal = true;
        }
    }

    private void ApplyBoidZeroPathFollowing()
    {
        if (!boidZeroNavigatingTowardGoal || boidZeroPath == null || boidZeroPath.corners == null || boidZeroPath.corners.Length == 0) return;

        // If we've passed the last corner, stop navigating
        if (currentCorner >= boidZeroPath.corners.Length)
        {
            boidZeroNavigatingTowardGoal = false;
            return;
        }
    
        Vector3 currentPos   = boids[0].position;
        Vector3 targetCorner = boidZeroPath.corners[currentCorner];

        // Direction from boid 0 to current corner
        Vector3 toCorner = targetCorner - currentPos;
        float dist = toCorner.magnitude;

        // If close to the current corner, move to the next one
        const float cornerReachThreshold = 1.0f;
        if (dist < cornerReachThreshold)
        {
            currentCorner++;
            if (currentCorner >= boidZeroPath.corners.Length)
            {
                boidZeroNavigatingTowardGoal = false;
                return;
            }

            targetCorner = boidZeroPath.corners[currentCorner];
            toCorner = targetCorner - currentPos;
            dist = toCorner.magnitude;
            if (dist <= 0.0001f) return;
        }

        Vector3 desiredDir      = toCorner.normalized;
        Vector3 desiredVelocity = desiredDir * boidForceScale;

        Vector3 v = boids[0].velocity;
        Vector3 pathSteer = (desiredVelocity - v) * goalWeight;

        boids[0].currentTotalForce += pathSteer;
    }
}

